﻿using System;

class ATM
{
    private double balance;

    public ATM(double initialBalance)
    {
        balance = initialBalance;
    }

    public double CheckBalance()
    {
        return balance;
    }

    public void Deposit(double amount)
    {
        balance += amount;
        Console.WriteLine($"Deposited ${amount}. New balance: ${balance}");
    }

    public void Withdraw(double amount)
    {
        if (amount > balance)
        {
            Console.WriteLine("Insufficient funds.");
        }
        else
        {
            balance -= amount;
            Console.WriteLine($"Withdrew ${amount}. New balance: ${balance}");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        ATM atm = new ATM(1000);

        while (true)
        {
            Console.WriteLine("ATM Menu:");
            Console.WriteLine("1. Check Balance");
            Console.WriteLine("2. Deposit");
            Console.WriteLine("3. Withdraw");
            Console.WriteLine("4. Exit");
            Console.Write("Enter choice: ");

            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine($"Current balance: ${atm.CheckBalance()}");
                    break;
                case 2:
                    Console.Write("Enter amount to deposit: ");
                    double depositAmount = Convert.ToDouble(Console.ReadLine());
                    atm.Deposit(depositAmount);
                    break;
                case 3:
                    Console.WriteLine("1. Select from predefined amounts");
                    Console.WriteLine("2. Enter your own amount");
                    Console.Write("Enter choice: ");
                    int withdrawalChoice = Convert.ToInt32(Console.ReadLine());

                    double withdrawAmount = 0;

                    if (withdrawalChoice == 1)
                    {
                        Console.WriteLine("Select withdrawal amount:");
                        Console.WriteLine("1. $20");
                        Console.WriteLine("2. $50");
                        Console.WriteLine("3. $100");
                        Console.Write("Enter choice: ");
                        int predefinedChoice = Convert.ToInt32(Console.ReadLine());

                        switch (predefinedChoice)
                        {
                            case 1:
                                withdrawAmount = 20;
                                break;
                            case 2:
                                withdrawAmount = 50;
                                break;
                            case 3:
                                withdrawAmount = 100;
                                break;
                            default:
                                Console.WriteLine("Invalid choice.");
                                break;
                        }
                    }
                    else if (withdrawalChoice == 2)
                    {
                        Console.Write("Enter withdrawal amount: ");
                        withdrawAmount = Convert.ToDouble(Console.ReadLine());
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice.");
                    }

                    atm.Withdraw(withdrawAmount);
                    break;
                case 4:
                    Console.WriteLine("Exiting ATM. Thank you!");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please select again.");
                    break;
            }

            Console.WriteLine();
        }
    }
}


